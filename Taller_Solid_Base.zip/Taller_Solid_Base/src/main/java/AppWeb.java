public class AppWeb {
    LogIn logIn;
    LogInAdmin logInAdmin;
    MySQL mySQL;
    public AppWeb (LogIn logIn, MySQL mySQL) {
        // Logic
    }
    public AppWeb (LogInAdmin logInAdmin, MySQL mySQL) {
        // Logic
    }
    public void connectToDatabase (MySQL mySQL) {
        // Logic
    }
}

