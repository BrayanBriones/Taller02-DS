/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.taller_solid_base;

/**
 *
 * @author USER
 */
public class Taller_Solid_Base {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}

